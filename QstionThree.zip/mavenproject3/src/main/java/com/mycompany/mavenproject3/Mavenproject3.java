package com.mycompany.mavenproject3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

class FaturamentoDiario {
    public int dia;
    public double valor;

    public FaturamentoDiario(int dia, double valor) {
        this.dia = dia;
        this.valor = valor;
    }
}

public class Mavenproject3 {

    public static void main(String[] args) throws Exception {
        // Lê o conteúdo do arquivo JSON
        String caminhoArquivo = "dados.json";
        String conteudoJson = new String(Files.readAllBytes(Paths.get(caminhoArquivo)));

        // Converte o conteúdo para um JSONArray
        JSONArray faturamentoArray = new JSONArray(conteudoJson);
        
        List<FaturamentoDiario> faturamentos = new ArrayList<>();

        // Itera sobre os itens do JSONArray e cria os objetos FaturamentoDiario
        for (int i = 0; i < faturamentoArray.length(); i++) {
            JSONObject obj = faturamentoArray.getJSONObject(i);
            int dia = obj.getInt("dia");
            double valor = obj.getDouble("valor");
            faturamentos.add(new FaturamentoDiario(dia, valor));
        }

        // Filtra os dias com faturamento maior que zero
        List<FaturamentoDiario> faturamentosValidos = new ArrayList<>();
        for (FaturamentoDiario f : faturamentos) {
            if (f.valor > 0) {
                faturamentosValidos.add(f);
            }
        }

        // Calcula o menor, maior faturamento e média
        double menorFaturamento = faturamentosValidos.stream().mapToDouble(f -> f.valor).min().orElse(0);
        double maiorFaturamento = faturamentosValidos.stream().mapToDouble(f -> f.valor).max().orElse(0);
        double mediaMensal = faturamentosValidos.stream().mapToDouble(f -> f.valor).average().orElse(0);
        long diasAcimaDaMedia = faturamentosValidos.stream().filter(f -> f.valor > mediaMensal).count();

        // Exibe os resultados
        System.out.println("Menor faturamento: " + menorFaturamento);
        System.out.println("Maior faturamento: " + maiorFaturamento);
        System.out.println("Dias com faturamento acima da média mensal: " + diasAcimaDaMedia);
    }
}
